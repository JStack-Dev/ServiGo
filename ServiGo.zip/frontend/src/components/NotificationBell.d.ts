export default function NotificationBell(): import("react/jsx-runtime").JSX.Element;
