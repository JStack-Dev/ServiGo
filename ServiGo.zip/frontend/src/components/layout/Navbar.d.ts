export default function Navbar(): import("react/jsx-runtime").JSX.Element;
