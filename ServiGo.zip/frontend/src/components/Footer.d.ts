declare const Footer: () => import("react/jsx-runtime").JSX.Element;
export default Footer;
