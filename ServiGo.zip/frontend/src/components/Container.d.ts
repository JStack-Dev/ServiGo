import React from "react";
interface ContainerProps {
    children: React.ReactNode;
    className?: string;
}
declare const Container: React.FC<ContainerProps>;
export default Container;
