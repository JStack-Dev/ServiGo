export default function ThemeToggle(): import("react/jsx-runtime").JSX.Element;
