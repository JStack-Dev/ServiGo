export declare const getUserProfile: () => Promise<any>;
export declare const updateUserProfile: (data: {
    name?: string;
    email?: string;
    password?: string;
}) => Promise<any>;
