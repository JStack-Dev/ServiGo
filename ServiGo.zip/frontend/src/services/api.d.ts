declare const api: import("axios").AxiosInstance;
export default api;
