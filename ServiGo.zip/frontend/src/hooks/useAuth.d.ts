export declare function useAuth(): import("@/context/authContext").AuthContextProps;
export default useAuth;
