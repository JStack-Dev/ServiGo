export declare const useTheme: () => {
    theme: string;
    toggleTheme: () => void;
};
