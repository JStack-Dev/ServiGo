export default function MainLayout(): import("react/jsx-runtime").JSX.Element;
