export default function Chats(): import("react/jsx-runtime").JSX.Element;
