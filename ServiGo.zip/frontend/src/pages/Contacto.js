import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export default function Contacto() {
    return (_jsxs("div", { className: "min-h-screen bg-gray-50 p-6", children: [_jsx("h1", { className: "text-4xl font-bold text-primary", children: "Contacto" }), _jsx("p", { className: "text-gray-600 mt-4", children: "Ponte en contacto con nosotros" })] }));
}
