export default function Services(): import("react/jsx-runtime").JSX.Element;
