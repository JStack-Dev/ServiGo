export default function Dashboard(): import("react/jsx-runtime").JSX.Element;
