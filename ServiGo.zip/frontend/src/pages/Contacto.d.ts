export default function Contacto(): import("react/jsx-runtime").JSX.Element;
