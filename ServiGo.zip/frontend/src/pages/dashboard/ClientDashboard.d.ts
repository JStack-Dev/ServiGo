export default function ClientDashboard(): import("react/jsx-runtime").JSX.Element;
