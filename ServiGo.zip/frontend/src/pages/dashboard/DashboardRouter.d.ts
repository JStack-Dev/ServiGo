export default function DashboardRouter(): import("react/jsx-runtime").JSX.Element;
