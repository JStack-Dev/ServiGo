export default function StatsDashboard(): import("react/jsx-runtime").JSX.Element;
