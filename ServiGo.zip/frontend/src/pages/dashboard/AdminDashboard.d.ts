export default function AdminDashboard(): import("react/jsx-runtime").JSX.Element;
