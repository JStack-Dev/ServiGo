export default function TechnicianDashboard(): import("react/jsx-runtime").JSX.Element;
