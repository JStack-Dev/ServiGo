declare const Register: () => import("react/jsx-runtime").JSX.Element;
export default Register;
