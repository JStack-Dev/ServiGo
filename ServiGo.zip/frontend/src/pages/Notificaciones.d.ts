export default function Notificaciones(): import("react/jsx-runtime").JSX.Element;
