export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-4xl font-bold text-primary">Dashboard</h1>
      <p className="text-gray-600 mt-4">Bienvenido a ServiGo Dashboard</p>
    </div>
  );
}