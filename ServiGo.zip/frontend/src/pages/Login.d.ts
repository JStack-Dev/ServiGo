declare const Login: () => import("react/jsx-runtime").JSX.Element;
export default Login;
