import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
const Servicios = () => (_jsxs("section", { children: [_jsx("h1", { className: "text-3xl font-display text-primary mb-4", children: "Nuestros Servicios" }), _jsx("p", { className: "text-neutral-dark", children: "Aqu\u00ED mostraremos la lista de servicios disponibles." })] }));
export default Servicios;
