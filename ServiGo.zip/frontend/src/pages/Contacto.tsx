export default function Contacto() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-4xl font-bold text-primary">Contacto</h1>
      <p className="text-gray-600 mt-4">Ponte en contacto con nosotros</p>
    </div>
  );
}