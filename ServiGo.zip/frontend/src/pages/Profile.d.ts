export default function Profile(): import("react/jsx-runtime").JSX.Element;
