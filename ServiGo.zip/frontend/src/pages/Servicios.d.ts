declare const Servicios: () => import("react/jsx-runtime").JSX.Element;
export default Servicios;
