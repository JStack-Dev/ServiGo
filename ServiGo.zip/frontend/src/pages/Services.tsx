export default function Services() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-4xl font-bold text-primary">Servicios</h1>
      <p className="text-gray-600 mt-4">Lista de servicios disponibles</p>
    </div>
  );
}