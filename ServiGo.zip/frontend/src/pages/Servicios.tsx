const Servicios = () => (
  <section>
    <h1 className="text-3xl font-display text-primary mb-4">Nuestros Servicios</h1>
    <p className="text-neutral-dark">Aquí mostraremos la lista de servicios disponibles.</p>
  </section>
);

export default Servicios;
