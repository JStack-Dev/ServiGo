declare const AppRouter: () => import("react/jsx-runtime").JSX.Element;
export default AppRouter;
