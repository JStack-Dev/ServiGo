import { ReactElement } from "react";
export default function PrivateRoute(): ReactElement;
